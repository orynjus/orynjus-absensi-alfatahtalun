import { useState, useEffect } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { useAuth } from "@/lib/auth";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";
import QRCode from "react-qr-code";
import {
  LayoutDashboard, Users, Calendar, QrCode, FileSpreadsheet, Settings, LogOut,
  Lock, Unlock, Plus, Trash2, Edit, Download, Printer, UserPlus, Search, ClipboardEdit, MessageSquare
} from "lucide-react";

export default function AdminDashboard() {
  const { user, logout } = useAuth();
  const { toast } = useToast();
  const [activeTab, setActiveTab] = useState("overview");

  return (
    <div className="min-h-screen bg-background flex">
      <aside className="w-64 border-r bg-card hidden md:flex flex-col no-print">
        <div className="p-4 border-b">
          <h2 className="font-bold text-lg">Admin Panel</h2>
          <p className="text-sm text-muted-foreground">{user?.name}</p>
        </div>
        <nav className="flex-1 p-2 space-y-1">
          {[
            { id: "overview", label: "Overview", icon: LayoutDashboard },
            { id: "settings", label: "Setelan", icon: Settings },
            { id: "users", label: "Kelola User", icon: Users },
            { id: "manual", label: "Absen Manual", icon: ClipboardEdit },
            { id: "qrcodes", label: "Cetak QR Code", icon: QrCode },
            { id: "recap", label: "Rekap Absensi", icon: FileSpreadsheet },
          ].map(item => (
            <button
              key={item.id}
              onClick={() => setActiveTab(item.id)}
              data-testid={`nav-${item.id}`}
              className={`w-full flex items-center gap-2 px-3 py-2 rounded-lg text-sm transition-colors ${
                activeTab === item.id ? "bg-primary text-primary-foreground" : "hover:bg-muted"
              }`}
            >
              <item.icon className="w-4 h-4" />
              {item.label}
            </button>
          ))}
        </nav>
        <div className="p-2 border-t">
          <button onClick={logout} className="w-full flex items-center gap-2 px-3 py-2 rounded-lg text-sm text-destructive hover:bg-destructive/10" data-testid="button-logout">
            <LogOut className="w-4 h-4" /> Keluar
          </button>
        </div>
      </aside>

      <main className="flex-1 p-3 sm:p-4 md:p-6 overflow-auto">
        <div className="md:hidden mb-4 no-print">
          <div className="flex gap-1.5 overflow-x-auto pb-2 -mx-1 px-1 scrollbar-hide">
            {["overview","settings","users","manual","qrcodes","recap"].map(tab => (
              <Button key={tab} variant={activeTab === tab ? "default" : "outline"} size="sm" className="flex-shrink-0 text-xs" onClick={() => setActiveTab(tab)}>
                {tab === "overview" ? "Overview" : tab === "settings" ? "Setelan" : tab === "users" ? "Users" : tab === "manual" ? "Manual" : tab === "qrcodes" ? "QR" : "Rekap"}
              </Button>
            ))}
            <Button variant="ghost" size="sm" onClick={logout} className="text-destructive flex-shrink-0"><LogOut className="w-4 h-4" /></Button>
          </div>
        </div>

        {activeTab === "overview" && <OverviewTab />}
        {activeTab === "settings" && <SettingsTab />}
        {activeTab === "users" && <UsersTab />}
        {activeTab === "manual" && <ManualAttendanceTab />}
        {activeTab === "qrcodes" && <QRCodesTab />}
        {activeTab === "recap" && <RecapTab />}
      </main>
    </div>
  );
}

function OverviewTab() {
  const { data: users } = useQuery<any[]>({ queryKey: ["/api/admin/users"] });
  const today = new Date().toISOString().split("T")[0];
  const { data: todayAttendance } = useQuery<any[]>({ queryKey: ["/api/admin/attendance", today], queryFn: async () => {
    const res = await fetch(`/api/admin/attendance?startDate=${today}&endDate=${today}`, { credentials: "include" });
    return res.json();
  }});
  const [expandedStatus, setExpandedStatus] = useState<string | null>(null);

  const students = users?.filter(u => u.role === "siswa") || [];
  const teachers = users?.filter(u => u.role === "guru" || u.role === "wali_kelas") || [];

  const hadirList = todayAttendance?.filter(a => a.status === "hadir") || [];
  const telatList = todayAttendance?.filter(a => a.status === "telat") || [];
  const pulangList = todayAttendance?.filter(a => a.checkOutTime) || [];
  const izinList = todayAttendance?.filter(a => a.status === "izin" || a.status === "sakit") || [];
  const alphaList = todayAttendance?.filter(a => a.status === "alpha") || [];

  const attendedIds = new Set(todayAttendance?.map(a => a.userId) || []);
  const belumScanList = students.filter(s => !attendedIds.has(s.id));

  const statusSections = [
    { key: "hadir", label: "Hadir", count: hadirList.length, color: "bg-green-500", list: hadirList, icon: "✓" },
    { key: "telat", label: "Terlambat", count: telatList.length, color: "bg-yellow-500", list: telatList, icon: "⏰" },
    { key: "pulang", label: "Sudah Pulang", count: pulangList.length, color: "bg-blue-500", list: pulangList, icon: "🏠" },
    { key: "izin", label: "Izin/Sakit", count: izinList.length, color: "bg-orange-500", list: izinList, icon: "📋" },
    { key: "alpha", label: "Alpha", count: alphaList.length, color: "bg-red-500", list: alphaList, icon: "✗" },
    { key: "belum", label: "Belum Scan", count: belumScanList.length, color: "bg-gray-400", list: belumScanList, icon: "—" },
  ];

  return (
    <div>
      <h2 className="text-2xl font-bold mb-4">Overview</h2>
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
        <Card>
          <CardContent className="p-6">
            <p className="text-sm text-muted-foreground">Total Siswa</p>
            <p className="text-3xl font-bold" data-testid="text-total-students">{students.length}</p>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-6">
            <p className="text-sm text-muted-foreground">Total Guru</p>
            <p className="text-3xl font-bold" data-testid="text-total-teachers">{teachers.length}</p>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-6">
            <p className="text-sm text-muted-foreground">Total User</p>
            <p className="text-3xl font-bold" data-testid="text-total-users">{users?.length || 0}</p>
          </CardContent>
        </Card>
      </div>

      <h3 className="text-sm sm:text-lg font-semibold mb-3">Kehadiran Hari Ini — {new Date().toLocaleDateString("id-ID", { weekday: "long", day: "numeric", month: "long", year: "numeric" })}</h3>
      <div className="grid grid-cols-3 sm:grid-cols-3 md:grid-cols-6 gap-2 sm:gap-3 mb-4">
        {statusSections.map(s => (
          <button
            key={s.key}
            onClick={() => setExpandedStatus(expandedStatus === s.key ? null : s.key)}
            className={`rounded-lg p-2 sm:p-3 text-center transition-all border ${expandedStatus === s.key ? "ring-2 ring-primary" : "hover:shadow-md"}`}
            data-testid={`card-status-${s.key}`}
          >
            <div className={`w-6 h-6 sm:w-8 sm:h-8 rounded-full ${s.color} text-white flex items-center justify-center mx-auto mb-1 text-xs sm:text-sm`}>{s.icon}</div>
            <p className="text-lg sm:text-2xl font-bold">{s.count}</p>
            <p className="text-[10px] sm:text-xs text-muted-foreground leading-tight">{s.label}</p>
          </button>
        ))}
      </div>

      {expandedStatus && (() => {
        const section = statusSections.find(s => s.key === expandedStatus);
        if (!section) return null;
        const isBelumScan = expandedStatus === "belum";
        return (
          <Card className="mb-4">
            <CardHeader className="pb-2">
              <CardTitle className="text-base">{section.label} ({section.count})</CardTitle>
            </CardHeader>
            <CardContent>
              {section.count === 0 ? (
                <p className="text-sm text-muted-foreground text-center py-4">Tidak ada data</p>
              ) : (
                <div className="border rounded-lg overflow-auto max-h-[40vh]">
                  <table className="w-full text-sm">
                    <thead className="bg-muted/50 sticky top-0">
                      <tr>
                        <th className="px-3 py-2 text-left text-xs">#</th>
                        <th className="px-3 py-2 text-left text-xs">Nama</th>
                        <th className="px-3 py-2 text-left text-xs">Kelas</th>
                        {!isBelumScan && <th className="px-3 py-2 text-left text-xs">Jam Datang</th>}
                        {!isBelumScan && <th className="px-3 py-2 text-left text-xs">Jam Pulang</th>}
                        {!isBelumScan && <th className="px-3 py-2 text-left text-xs">Status</th>}
                      </tr>
                    </thead>
                    <tbody>
                      {section.list.map((item: any, i: number) => {
                        const user = isBelumScan ? item : item.user;
                        return (
                          <tr key={i} className="border-t" data-testid={`row-status-${expandedStatus}-${i}`}>
                            <td className="px-3 py-1.5 text-xs text-muted-foreground">{i + 1}</td>
                            <td className="px-3 py-1.5 text-xs">{user?.name || "-"}</td>
                            <td className="px-3 py-1.5 text-xs">{user?.className || "-"}</td>
                            {!isBelumScan && <td className="px-3 py-1.5 text-xs">{item.checkInTime || "-"}</td>}
                            {!isBelumScan && <td className="px-3 py-1.5 text-xs">{item.checkOutTime || "-"}</td>}
                            {!isBelumScan && <td className="px-3 py-1.5 text-xs">
                              <Badge variant="outline" className="text-xs">{item.status}</Badge>
                            </td>}
                          </tr>
                        );
                      })}
                    </tbody>
                  </table>
                </div>
              )}
            </CardContent>
          </Card>
        );
      })()}
    </div>
  );
}

const DAY_LABELS: Record<string, string> = {
  senin: "Senin", selasa: "Selasa", rabu: "Rabu", kamis: "Kamis", jumat: "Jumat", sabtu: "Sabtu", minggu: "Minggu"
};
const DAY_KEYS = ["senin", "selasa", "rabu", "kamis", "jumat", "sabtu", "minggu"];
const DAY_INDICES: Record<string, number> = { minggu: 0, senin: 1, selasa: 2, rabu: 3, kamis: 4, jumat: 5, sabtu: 6 };

type DayScheduleType = { checkInStart: string; checkInEnd: string; checkOutStart: string; checkOutEnd: string; enabled: boolean };

function SettingsTab() {
  const { toast } = useToast();
  const { data: status } = useQuery<any>({ queryKey: ["/api/scanner/status"] });
  const { data: fullSettings } = useQuery<any>({ queryKey: ["/api/scanner/full-settings"] });
  const { data: holidays } = useQuery<any[]>({ queryKey: ["/api/holidays"] });

  const [settingsTab, setSettingsTab] = useState("scanner");

  const updateMutation = useMutation({
    mutationFn: async (data: any) => { await apiRequest("PUT", "/api/scanner/settings", data); },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/scanner/status"] });
      queryClient.invalidateQueries({ queryKey: ["/api/scanner/full-settings"] });
      toast({ title: "Pengaturan diperbarui" });
    },
  });

  const [lockPin, setLockPin] = useState("");
  const [lateThreshold, setLateThreshold] = useState("");
  const [fonnteToken, setFonnteToken] = useState("");
  const [fonnteTestPhone, setFonnteTestPhone] = useState("");
  const [fonnteTestLoading, setFonnteTestLoading] = useState(false);
  const [googleSheetId, setGoogleSheetId] = useState("");
  const [googleDriveFolderId, setGoogleDriveFolderId] = useState("");
  const [checkInStart, setCheckInStart] = useState("");
  const [checkInEnd, setCheckInEnd] = useState("");
  const [checkOutStart, setCheckOutStart] = useState("");
  const [checkOutEnd, setCheckOutEnd] = useState("");

  const defaultSchedule: DayScheduleType = {
    checkInStart: fullSettings?.checkInStart || "06:30",
    checkInEnd: fullSettings?.checkInEnd || "08:00",
    checkOutStart: fullSettings?.checkOutStart || "14:00",
    checkOutEnd: fullSettings?.checkOutEnd || "16:00",
    enabled: true,
  };

  const [weeklySchedule, setWeeklySchedule] = useState<Record<string, DayScheduleType>>({});
  const [holidayDays, setHolidayDays] = useState<number[]>([]);

  useEffect(() => {
    if (fullSettings) {
      try {
        setWeeklySchedule(fullSettings.weeklySchedule ? JSON.parse(fullSettings.weeklySchedule) : {});
      } catch { setWeeklySchedule({}); }
      const days = (fullSettings.defaultHolidayDays || "0,6").split(",").map((d: string) => parseInt(d.trim()));
      setHolidayDays(days);
      setFonnteToken(fullSettings.fonnteToken || "");
      setGoogleSheetId(fullSettings.googleSheetId || "");
      setGoogleDriveFolderId(fullSettings.googleDriveFolderId || "");
    }
  }, [fullSettings]);

  const getDay = (day: string): DayScheduleType => weeklySchedule[day] || { ...defaultSchedule };
  const setDay = (day: string, field: string, value: any) => {
    setWeeklySchedule(prev => ({
      ...prev,
      [day]: { ...getDay(day), [field]: value }
    }));
  };

  const toggleHolidayDay = (dayIndex: number) => {
    setHolidayDays(prev => prev.includes(dayIndex) ? prev.filter(d => d !== dayIndex) : [...prev, dayIndex]);
  };

  const handleSaveGeneral = () => {
    updateMutation.mutate({
      checkInStart: checkInStart || undefined,
      checkInEnd: checkInEnd || undefined,
      checkOutStart: checkOutStart || undefined,
      checkOutEnd: checkOutEnd || undefined,
      lockPin: lockPin || undefined,
      lateThreshold: lateThreshold || undefined,
    });
  };

  const handleSaveWeekly = () => {
    updateMutation.mutate({ weeklySchedule: JSON.stringify(weeklySchedule) });
  };

  const handleSaveHolidayDays = () => {
    updateMutation.mutate({ defaultHolidayDays: holidayDays.join(",") });
  };

  const handleSaveFonnte = () => {
    updateMutation.mutate({ fonnteToken: fonnteToken });
  };

  const handleSaveGoogle = () => {
    updateMutation.mutate({ googleSheetId, googleDriveFolderId });
  };

  const handleTestFonnte = async () => {
    if (!fonnteToken || !fonnteTestPhone) {
      toast({ title: "Isi token dan nomor HP tujuan", variant: "destructive" });
      return;
    }
    setFonnteTestLoading(true);
    try {
      const res = await fetch("https://api.fonnte.com/send", {
        method: "POST",
        headers: { "Authorization": fonnteToken, "Content-Type": "application/json" },
        body: JSON.stringify({ target: fonnteTestPhone, message: "Tes koneksi Fonnte dari Sistem Absensi Digital ✅" }),
      });
      const data = await res.json();
      if (data.status) {
        toast({ title: "Berhasil!", description: "Pesan tes terkirim ke " + fonnteTestPhone });
      } else {
        toast({ title: "Gagal kirim", description: data.reason || "Periksa token dan nomor tujuan", variant: "destructive" });
      }
    } catch {
      toast({ title: "Gagal koneksi ke Fonnte", variant: "destructive" });
    } finally {
      setFonnteTestLoading(false);
    }
  };

  const [holidayDate, setHolidayDate] = useState("");
  const [holidayDesc, setHolidayDesc] = useState("");

  const addHolidayMutation = useMutation({
    mutationFn: async (data: any) => { await apiRequest("POST", "/api/holidays", data); },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/holidays"] });
      setHolidayDate(""); setHolidayDesc("");
      toast({ title: "Hari libur ditambahkan" });
    },
  });
  const deleteHolidayMutation = useMutation({
    mutationFn: async (id: number) => { await apiRequest("DELETE", `/api/holidays/${id}`); },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/holidays"] });
      toast({ title: "Hari libur dihapus" });
    },
  });

  return (
    <div>
      <h2 className="text-2xl font-bold mb-4">Setelan</h2>
      <Tabs value={settingsTab} onValueChange={setSettingsTab}>
        <div className="overflow-x-auto -mx-1 px-1 mb-4">
          <TabsList className="w-max">
            <TabsTrigger value="scanner" data-testid="settings-tab-scanner" className="text-xs sm:text-sm">Scanner & PIN</TabsTrigger>
            <TabsTrigger value="schedule" data-testid="settings-tab-schedule" className="text-xs sm:text-sm">Jadwal</TabsTrigger>
            <TabsTrigger value="holidays" data-testid="settings-tab-holidays" className="text-xs sm:text-sm">Hari Libur</TabsTrigger>
            <TabsTrigger value="google" data-testid="settings-tab-google" className="text-xs sm:text-sm">Google</TabsTrigger>
            <TabsTrigger value="fonnte" data-testid="settings-tab-fonnte" className="text-xs sm:text-sm">Fonnte</TabsTrigger>
          </TabsList>
        </div>

        <TabsContent value="scanner">
          <div className="grid gap-4 md:grid-cols-2">
            <Card>
              <CardHeader><CardTitle>Status Scanner</CardTitle></CardHeader>
              <CardContent className="space-y-4">
                <div className="flex items-center justify-between">
                  <span>Scanner saat ini:</span>
                  <Badge variant={status?.isLocked ? "destructive" : "default"} data-testid="badge-scanner-status">
                    {status?.isLocked ? "Terkunci" : "Aktif"}
                  </Badge>
                </div>
                <Button
                  onClick={() => updateMutation.mutate({ isLocked: !status?.isLocked })}
                  variant={status?.isLocked ? "default" : "destructive"}
                  className="w-full"
                  data-testid="button-toggle-lock"
                >
                  {status?.isLocked ? <><Unlock className="w-4 h-4 mr-2" />Buka Kunci Scanner</> : <><Lock className="w-4 h-4 mr-2" />Kunci Scanner</>}
                </Button>
                <div>
                  <Label>PIN Kunci Scanner</Label>
                  <Input type="text" inputMode="numeric" maxLength={6} value={lockPin} onChange={e => setLockPin(e.target.value)} placeholder="PIN saat ini: ****" data-testid="input-lock-pin" />
                  <p className="text-xs text-muted-foreground mt-1">PIN digunakan untuk kunci/buka scanner dari halaman utama</p>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader><CardTitle>Jadwal Default</CardTitle></CardHeader>
              <CardContent className="space-y-3">
                <p className="text-xs text-muted-foreground">Jadwal default digunakan jika hari tidak diatur secara khusus</p>
                <div className="grid grid-cols-2 gap-2">
                  <div>
                    <Label>Check-in Mulai</Label>
                    <Input type="time" value={checkInStart || fullSettings?.checkInStart || ""} onChange={e => setCheckInStart(e.target.value)} data-testid="input-checkin-start" />
                  </div>
                  <div>
                    <Label>Check-in Selesai</Label>
                    <Input type="time" value={checkInEnd || fullSettings?.checkInEnd || ""} onChange={e => setCheckInEnd(e.target.value)} data-testid="input-checkin-end" />
                  </div>
                  <div>
                    <Label>Check-out Mulai</Label>
                    <Input type="time" value={checkOutStart || fullSettings?.checkOutStart || ""} onChange={e => setCheckOutStart(e.target.value)} data-testid="input-checkout-start" />
                  </div>
                  <div>
                    <Label>Check-out Selesai</Label>
                    <Input type="time" value={checkOutEnd || fullSettings?.checkOutEnd || ""} onChange={e => setCheckOutEnd(e.target.value)} data-testid="input-checkout-end" />
                  </div>
                </div>
                <div>
                  <Label>Batas Waktu Telat</Label>
                  <Input type="time" value={lateThreshold || fullSettings?.lateThreshold || ""} onChange={e => setLateThreshold(e.target.value)} data-testid="input-late-threshold" />
                  <p className="text-xs text-muted-foreground mt-1">Check-in setelah waktu ini dianggap terlambat</p>
                </div>
                <Button onClick={handleSaveGeneral} className="w-full" disabled={updateMutation.isPending} data-testid="button-save-general">Simpan Pengaturan</Button>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="schedule">
          <Card>
            <CardHeader>
              <CardTitle>Jadwal Scan Per Hari</CardTitle>
              <p className="text-sm text-muted-foreground">Atur jadwal scan untuk setiap hari. Kosongkan untuk menggunakan jadwal default.</p>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {DAY_KEYS.map(day => {
                  const schedule = getDay(day);
                  const isHoliday = holidayDays.includes(DAY_INDICES[day]);
                  return (
                    <div key={day} className={`border rounded-lg p-3 ${isHoliday ? "opacity-50" : ""}`} data-testid={`schedule-${day}`}>
                      <div className="flex items-center justify-between mb-2">
                        <div className="flex items-center gap-2">
                          <label className="flex items-center gap-2 cursor-pointer">
                            <input
                              type="checkbox"
                              checked={schedule.enabled && !isHoliday}
                              onChange={e => setDay(day, "enabled", e.target.checked)}
                              disabled={isHoliday}
                              className="w-4 h-4"
                              data-testid={`checkbox-${day}-enabled`}
                            />
                            <span className="font-medium">{DAY_LABELS[day]}</span>
                          </label>
                          {isHoliday && <Badge variant="outline" className="text-xs">Libur Default</Badge>}
                        </div>
                        {!schedule.enabled && !isHoliday && <Badge variant="secondary" className="text-xs">Nonaktif</Badge>}
                      </div>
                      {schedule.enabled && !isHoliday && (
                        <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                          <div>
                            <Label className="text-xs">Masuk Mulai</Label>
                            <Input type="time" value={schedule.checkInStart} onChange={e => setDay(day, "checkInStart", e.target.value)} className="h-8 text-xs" data-testid={`input-${day}-checkin-start`} />
                          </div>
                          <div>
                            <Label className="text-xs">Masuk Selesai</Label>
                            <Input type="time" value={schedule.checkInEnd} onChange={e => setDay(day, "checkInEnd", e.target.value)} className="h-8 text-xs" data-testid={`input-${day}-checkin-end`} />
                          </div>
                          <div>
                            <Label className="text-xs">Pulang Mulai</Label>
                            <Input type="time" value={schedule.checkOutStart} onChange={e => setDay(day, "checkOutStart", e.target.value)} className="h-8 text-xs" data-testid={`input-${day}-checkout-start`} />
                          </div>
                          <div>
                            <Label className="text-xs">Pulang Selesai</Label>
                            <Input type="time" value={schedule.checkOutEnd} onChange={e => setDay(day, "checkOutEnd", e.target.value)} className="h-8 text-xs" data-testid={`input-${day}-checkout-end`} />
                          </div>
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>
              <Button onClick={handleSaveWeekly} className="w-full mt-4" disabled={updateMutation.isPending} data-testid="button-save-weekly">Simpan Jadwal Mingguan</Button>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="holidays">
          <div className="grid gap-4 md:grid-cols-2">
            <Card>
              <CardHeader><CardTitle>Hari Libur Default (Mingguan)</CardTitle></CardHeader>
              <CardContent className="space-y-3">
                <p className="text-sm text-muted-foreground">Pilih hari yang selalu dianggap libur setiap minggu</p>
                <div className="grid grid-cols-2 gap-2">
                  {[
                    { index: 1, label: "Senin" }, { index: 2, label: "Selasa" }, { index: 3, label: "Rabu" },
                    { index: 4, label: "Kamis" }, { index: 5, label: "Jumat" }, { index: 6, label: "Sabtu" },
                    { index: 0, label: "Minggu" },
                  ].map(d => (
                    <label key={d.index} className={`flex items-center gap-2 p-2 border rounded-lg cursor-pointer transition-colors ${holidayDays.includes(d.index) ? "bg-red-50 border-red-300 dark:bg-red-950 dark:border-red-800" : "hover:bg-muted"}`} data-testid={`toggle-holiday-${d.index}`}>
                      <input type="checkbox" checked={holidayDays.includes(d.index)} onChange={() => toggleHolidayDay(d.index)} className="w-4 h-4" />
                      <span className={holidayDays.includes(d.index) ? "text-red-600 font-medium dark:text-red-400" : ""}>{d.label}</span>
                    </label>
                  ))}
                </div>
                <Button onClick={handleSaveHolidayDays} className="w-full" disabled={updateMutation.isPending} data-testid="button-save-holiday-days">Simpan Hari Libur Default</Button>
              </CardContent>
            </Card>

            <Card>
              <CardHeader><CardTitle>Hari Libur Khusus</CardTitle></CardHeader>
              <CardContent className="space-y-3">
                <p className="text-sm text-muted-foreground">Tambahkan tanggal libur tertentu (hari nasional, kegiatan sekolah, dll)</p>
                <div className="flex gap-2">
                  <Input type="date" value={holidayDate} onChange={e => setHolidayDate(e.target.value)} data-testid="input-holiday-date" />
                  <Input placeholder="Keterangan" value={holidayDesc} onChange={e => setHolidayDesc(e.target.value)} data-testid="input-holiday-desc" />
                  <Button onClick={() => addHolidayMutation.mutate({ date: holidayDate, description: holidayDesc })} disabled={!holidayDate || !holidayDesc} data-testid="button-add-holiday">
                    <Plus className="w-4 h-4" />
                  </Button>
                </div>
                <div className="space-y-2 max-h-60 overflow-auto">
                  {holidays?.map((h: any) => (
                    <div key={h.id} className="flex items-center justify-between p-2 border rounded-lg" data-testid={`row-holiday-${h.id}`}>
                      <div>
                        <span className="font-medium text-sm">{h.date}</span>
                        <span className="text-muted-foreground text-sm ml-2">{h.description}</span>
                      </div>
                      <Button size="sm" variant="ghost" className="text-destructive h-7" onClick={() => deleteHolidayMutation.mutate(h.id)} data-testid={`button-delete-holiday-${h.id}`}>
                        <Trash2 className="w-3 h-3" />
                      </Button>
                    </div>
                  ))}
                  {(!holidays || holidays.length === 0) && <p className="text-muted-foreground text-center py-4 text-sm">Belum ada hari libur khusus</p>}
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="google">
          <Card>
            <CardHeader><CardTitle>Pengaturan Google Sheet & Drive</CardTitle></CardHeader>
            <CardContent className="space-y-4">
              <p className="text-xs text-muted-foreground">
                Konfigurasi ID Google Sheet untuk sinkronisasi data absensi dan import user, serta ID Folder Google Drive untuk upload bukti izin/sakit.
              </p>
              <div>
                <Label>Google Sheet ID</Label>
                <Input
                  placeholder="1LgFgRFsgM_Rggu0ZegFBtHBIeh5gkVSnQ-rudSb_MvY"
                  value={googleSheetId}
                  onChange={e => setGoogleSheetId(e.target.value)}
                  data-testid="input-google-sheet-id"
                />
                <p className="text-xs text-muted-foreground mt-1">
                  ID spreadsheet dari URL: docs.google.com/spreadsheets/d/<span className="font-mono text-primary">ID_DISINI</span>/edit
                </p>
              </div>
              <div>
                <Label>Google Drive Folder ID</Label>
                <Input
                  placeholder="11vJgEVtglUa50h9P1hZcVf0ceqeVq5tJ"
                  value={googleDriveFolderId}
                  onChange={e => setGoogleDriveFolderId(e.target.value)}
                  data-testid="input-google-drive-folder-id"
                />
                <p className="text-xs text-muted-foreground mt-1">
                  ID folder dari URL: drive.google.com/drive/folders/<span className="font-mono text-primary">ID_DISINI</span>
                </p>
              </div>
              <Button onClick={handleSaveGoogle} className="w-full" disabled={updateMutation.isPending} data-testid="button-save-google">
                Simpan Pengaturan Google
              </Button>
              <div className="pt-3 border-t space-y-2">
                <p className="text-xs font-medium text-muted-foreground">Status Konfigurasi:</p>
                <div className="flex gap-2">
                  <Badge variant={googleSheetId ? "default" : "outline"} data-testid="badge-sheet-status">
                    Sheet: {googleSheetId ? "Terpasang" : "Default"}
                  </Badge>
                  <Badge variant={googleDriveFolderId ? "default" : "outline"} data-testid="badge-drive-status">
                    Drive: {googleDriveFolderId ? "Terpasang" : "Default"}
                  </Badge>
                </div>
                {googleSheetId && (
                  <a href={`https://docs.google.com/spreadsheets/d/${googleSheetId}/edit`} target="_blank" rel="noopener noreferrer" className="text-xs text-primary underline block" data-testid="link-open-sheet">
                    Buka Google Sheet
                  </a>
                )}
                {googleDriveFolderId && (
                  <a href={`https://drive.google.com/drive/folders/${googleDriveFolderId}`} target="_blank" rel="noopener noreferrer" className="text-xs text-primary underline block" data-testid="link-open-drive">
                    Buka Google Drive Folder
                  </a>
                )}
              </div>
              <div className="text-xs text-muted-foreground space-y-1 pt-2 border-t">
                <p className="font-medium">Format sheet untuk import user:</p>
                <ul className="list-disc pl-4 space-y-0.5">
                  <li><strong>Tab "Siswa"</strong>: Nama, NISN, Kelas, No HP Ortu, Nama Ortu</li>
                  <li><strong>Tab "Guru"</strong>: Nama, NIP, No WA</li>
                  <li><strong>Tab "Wali Kelas"</strong>: Nama, NIP, Kelas, No WA</li>
                </ul>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="fonnte">
          <div className="grid gap-4 md:grid-cols-2">
            <Card>
              <CardHeader><CardTitle>Token API Fonnte</CardTitle></CardHeader>
              <CardContent className="space-y-4">
                <p className="text-xs text-muted-foreground">
                  Token API dari akun Fonnte Anda untuk mengirim notifikasi WhatsApp otomatis ke orang tua dan wali kelas.
                  Dapatkan token di <a href="https://fonnte.com" target="_blank" rel="noopener noreferrer" className="underline text-primary">fonnte.com</a>
                </p>
                <div>
                  <Label>Token API</Label>
                  <Input
                    type="password"
                    placeholder="Masukkan token Fonnte..."
                    value={fonnteToken}
                    onChange={e => setFonnteToken(e.target.value)}
                    data-testid="input-fonnte-token"
                  />
                </div>
                <Button onClick={handleSaveFonnte} className="w-full" disabled={updateMutation.isPending} data-testid="button-save-fonnte">
                  Simpan Token
                </Button>
                <div className="pt-2 border-t">
                  <Badge variant={fonnteToken ? "default" : "destructive"} data-testid="badge-fonnte-status">
                    {fonnteToken ? "Token Terpasang" : "Belum Dikonfigurasi"}
                  </Badge>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader><CardTitle>Tes Kirim WhatsApp</CardTitle></CardHeader>
              <CardContent className="space-y-4">
                <p className="text-xs text-muted-foreground">
                  Kirim pesan tes untuk memastikan koneksi Fonnte berfungsi dengan benar.
                </p>
                <div>
                  <Label>Nomor HP Tujuan</Label>
                  <Input
                    placeholder="08xxxxxxxxxx"
                    value={fonnteTestPhone}
                    onChange={e => setFonnteTestPhone(e.target.value)}
                    data-testid="input-fonnte-test-phone"
                  />
                </div>
                <Button onClick={handleTestFonnte} variant="outline" className="w-full" disabled={fonnteTestLoading || !fonnteToken} data-testid="button-test-fonnte">
                  <MessageSquare className="w-4 h-4 mr-2" />
                  {fonnteTestLoading ? "Mengirim..." : "Kirim Pesan Tes"}
                </Button>
                <div className="text-xs text-muted-foreground space-y-1 pt-2 border-t">
                  <p className="font-medium">Notifikasi WA dikirim saat:</p>
                  <ul className="list-disc pl-4 space-y-0.5">
                    <li>Siswa scan QR (check-in/check-out) → ke orang tua</li>
                    <li>Admin input absen manual → ke orang tua</li>
                    <li>Siswa ajukan izin/sakit → ke wali kelas</li>
                  </ul>
                </div>
              </CardContent>
            </Card>
          </div>

        </TabsContent>
      </Tabs>
    </div>
  );
}

function UsersTab() {
  const { toast } = useToast();
  const [showAdd, setShowAdd] = useState(false);
  const [editUser, setEditUser] = useState<any>(null);
  const [filterRole, setFilterRole] = useState<string>("all");
  const [search, setSearch] = useState("");
  const [showImport, setShowImport] = useState(false);
  const [importTab, setImportTab] = useState<string>("");
  const [previewData, setPreviewData] = useState<string[][] | null>(null);
  const [importLoading, setImportLoading] = useState(false);

  const { data: users } = useQuery<any[]>({ queryKey: ["/api/admin/users"] });

  const { data: sheetTabsData } = useQuery<{ tabs: string[] }>({
    queryKey: ["/api/admin/sheet-tabs"],
    enabled: showImport,
  });

  const handlePreview = async (tab: string) => {
    setImportTab(tab);
    try {
      const res = await apiRequest("GET", `/api/admin/sheet-preview?tab=${encodeURIComponent(tab)}`);
      const data = await res.json();
      setPreviewData(data.rows);
    } catch {
      toast({ title: "Gagal membaca data sheet", variant: "destructive" });
    }
  };

  const handleImport = async () => {
    if (!importTab) return;
    setImportLoading(true);
    try {
      const res = await apiRequest("POST", "/api/admin/import-users", { tab: importTab });
      const data = await res.json();
      queryClient.invalidateQueries({ queryKey: ["/api/admin/users"] });
      toast({
        title: `Import selesai`,
        description: `${data.imported} berhasil, ${data.skipped} dilewati dari ${data.total} baris${data.errors?.length ? "\n" + data.errors.slice(0, 5).join("; ") : ""}`,
      });
      setShowImport(false);
      setPreviewData(null);
      setImportTab("");
    } catch (err: any) {
      toast({ title: "Gagal import", description: err.message, variant: "destructive" });
    } finally {
      setImportLoading(false);
    }
  };

  const addMutation = useMutation({
    mutationFn: async (data: any) => {
      await apiRequest("POST", "/api/admin/users", data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/admin/users"] });
      setShowAdd(false);
      toast({ title: "User berhasil ditambahkan" });
    },
    onError: (err: any) => toast({ title: "Gagal", description: err.message, variant: "destructive" }),
  });

  const updateMutation = useMutation({
    mutationFn: async ({ id, ...data }: any) => {
      await apiRequest("PUT", `/api/admin/users/${id}`, data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/admin/users"] });
      setEditUser(null);
      toast({ title: "User berhasil diperbarui" });
    },
  });

  const deleteMutation = useMutation({
    mutationFn: async (id: number) => {
      await apiRequest("DELETE", `/api/admin/users/${id}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/admin/users"] });
      toast({ title: "User dihapus" });
    },
  });

  const filtered = users?.filter(u => {
    if (filterRole !== "all" && u.role !== filterRole) return false;
    if (search && !u.name.toLowerCase().includes(search.toLowerCase()) && !u.identifier.includes(search)) return false;
    return true;
  }) || [];

  return (
    <div>
      <div className="flex items-center justify-between mb-4">
        <h2 className="text-2xl font-bold">Kelola User</h2>
        <div className="flex gap-2">
          <Button variant="outline" onClick={() => setShowImport(true)} data-testid="button-import-sheet">
            <FileSpreadsheet className="w-4 h-4 mr-2" />Import dari Google Sheet
          </Button>
          <Button onClick={() => setShowAdd(true)} data-testid="button-add-user"><UserPlus className="w-4 h-4 mr-2" />Tambah User</Button>
        </div>
      </div>

      <div className="flex gap-2 mb-4">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
          <Input placeholder="Cari nama atau ID..." value={search} onChange={e => setSearch(e.target.value)} className="pl-9" data-testid="input-search-user" />
        </div>
        <Select value={filterRole} onValueChange={setFilterRole}>
          <SelectTrigger className="w-40" data-testid="select-filter-role"><SelectValue /></SelectTrigger>
          <SelectContent>
            <SelectItem value="all">Semua</SelectItem>
            <SelectItem value="siswa">Siswa</SelectItem>
            <SelectItem value="guru">Guru</SelectItem>
            <SelectItem value="wali_kelas">Wali Kelas</SelectItem>
          </SelectContent>
        </Select>
      </div>

      <div className="border rounded-lg overflow-auto">
        <table className="w-full text-sm">
          <thead className="bg-muted/50">
            <tr>
              <th className="px-4 py-2 text-left">Nama</th>
              <th className="px-4 py-2 text-left">ID</th>
              <th className="px-4 py-2 text-left">Role</th>
              <th className="px-4 py-2 text-left">Kelas</th>
              <th className="px-4 py-2 text-left">Aksi</th>
            </tr>
          </thead>
          <tbody>
            {filtered.map((u: any) => (
              <tr key={u.id} className="border-t" data-testid={`row-user-${u.id}`}>
                <td className="px-4 py-2">{u.name}</td>
                <td className="px-4 py-2 font-mono text-xs">{u.identifier}</td>
                <td className="px-4 py-2"><Badge variant="outline">{u.role}</Badge></td>
                <td className="px-4 py-2">{u.className || "-"}</td>
                <td className="px-4 py-2 flex gap-1">
                  <Button size="sm" variant="ghost" onClick={() => setEditUser(u)} data-testid={`button-edit-${u.id}`}><Edit className="w-3 h-3" /></Button>
                  {u.role !== "admin" && (
                    <Button size="sm" variant="ghost" className="text-destructive" onClick={() => { if (confirm("Hapus user ini?")) deleteMutation.mutate(u.id); }} data-testid={`button-delete-${u.id}`}>
                      <Trash2 className="w-3 h-3" />
                    </Button>
                  )}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      <UserFormDialog open={showAdd} onClose={() => setShowAdd(false)} onSubmit={(d) => addMutation.mutate(d)} title="Tambah User" />
      {editUser && (
        <UserFormDialog
          open={!!editUser}
          onClose={() => setEditUser(null)}
          onSubmit={(d) => updateMutation.mutate({ id: editUser.id, ...d })}
          title="Edit User"
          defaultValues={editUser}
        />
      )}

      <Dialog open={showImport} onOpenChange={(v) => { if (!v) { setShowImport(false); setPreviewData(null); setImportTab(""); } }}>
        <DialogContent className="max-w-3xl max-h-[80vh] overflow-auto">
          <DialogHeader>
            <DialogTitle>Import User dari Google Sheet</DialogTitle>
          </DialogHeader>
          <p className="text-sm text-muted-foreground mb-3">
            Pilih tab sheet untuk melihat preview data, lalu klik "Import" untuk menambahkan user baru. User dengan ID yang sudah ada akan dilewati.
          </p>
          <div className="flex gap-2 mb-4 flex-wrap">
            {sheetTabsData?.tabs?.filter(t => ["Siswa", "Guru", "Wali Kelas"].includes(t)).map(tab => (
              <Button
                key={tab}
                variant={importTab === tab ? "default" : "outline"}
                size="sm"
                onClick={() => handlePreview(tab)}
                data-testid={`button-sheet-tab-${tab}`}
              >
                {tab}
              </Button>
            ))}
          </div>
          {previewData && (
            <>
              <div className="border rounded-lg overflow-auto max-h-[40vh]">
                <table className="w-full text-sm">
                  <thead className="bg-muted/50 sticky top-0">
                    <tr>
                      <th className="px-3 py-2 text-left text-xs">#</th>
                      {importTab.toLowerCase() === "siswa" && (
                        <><th className="px-3 py-2 text-left text-xs">Nama</th><th className="px-3 py-2 text-left text-xs">NISN</th><th className="px-3 py-2 text-left text-xs">Kelas</th><th className="px-3 py-2 text-left text-xs">No HP Ortu</th><th className="px-3 py-2 text-left text-xs">Nama Ortu</th></>
                      )}
                      {importTab.toLowerCase() === "guru" && (
                        <><th className="px-3 py-2 text-left text-xs">Nama</th><th className="px-3 py-2 text-left text-xs">NIP</th><th className="px-3 py-2 text-left text-xs">No WA</th></>
                      )}
                      {importTab.toLowerCase() === "wali kelas" && (
                        <><th className="px-3 py-2 text-left text-xs">Nama</th><th className="px-3 py-2 text-left text-xs">NIP</th><th className="px-3 py-2 text-left text-xs">Kelas</th><th className="px-3 py-2 text-left text-xs">No WA</th></>
                      )}
                    </tr>
                  </thead>
                  <tbody>
                    {previewData.map((row, i) => (
                      <tr key={i} className="border-t">
                        <td className="px-3 py-1.5 text-xs text-muted-foreground">{i + 2}</td>
                        {row.map((cell, j) => (
                          <td key={j} className="px-3 py-1.5 text-xs">{cell || "-"}</td>
                        ))}
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
              <div className="flex items-center justify-between mt-3">
                <p className="text-sm text-muted-foreground">{previewData.length} baris ditemukan</p>
                <Button onClick={handleImport} disabled={importLoading || previewData.length === 0} data-testid="button-confirm-import">
                  {importLoading ? "Mengimport..." : `Import ${previewData.length} ${importTab}`}
                </Button>
              </div>
            </>
          )}
          {previewData?.length === 0 && (
            <p className="text-center text-muted-foreground py-8">Sheet kosong - tidak ada data untuk diimport</p>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}

function UserFormDialog({ open, onClose, onSubmit, title, defaultValues }: {
  open: boolean; onClose: () => void; onSubmit: (data: any) => void; title: string; defaultValues?: any;
}) {
  const [name, setName] = useState(defaultValues?.name || "");
  const [identifier, setIdentifier] = useState(defaultValues?.identifier || "");
  const [role, setRole] = useState(defaultValues?.role || "siswa");
  const [className, setClassName] = useState(defaultValues?.className || "");
  const [parentPhone, setParentPhone] = useState(defaultValues?.parentPhone || "");
  const [parentName, setParentName] = useState(defaultValues?.parentName || "");

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSubmit({ name, identifier, role, className: className || null, parentPhone: parentPhone || null, parentName: parentName || null });
  };

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent>
        <DialogHeader><DialogTitle>{title}</DialogTitle></DialogHeader>
        <form onSubmit={handleSubmit} className="space-y-3">
          <div><Label>Nama</Label><Input value={name} onChange={e => setName(e.target.value)} required data-testid="input-user-name" /></div>
          <div><Label>NISN/NIP/Username</Label><Input value={identifier} onChange={e => setIdentifier(e.target.value)} required data-testid="input-user-identifier" /></div>
          <div>
            <Label>Role</Label>
            <Select value={role} onValueChange={setRole}>
              <SelectTrigger data-testid="select-user-role"><SelectValue /></SelectTrigger>
              <SelectContent>
                <SelectItem value="siswa">Siswa</SelectItem>
                <SelectItem value="guru">Guru</SelectItem>
                <SelectItem value="wali_kelas">Wali Kelas</SelectItem>
              </SelectContent>
            </Select>
          </div>
          {(role === "siswa" || role === "wali_kelas") && (
            <div><Label>Kelas</Label><Input value={className} onChange={e => setClassName(e.target.value)} placeholder="contoh: XII-IPA-1" data-testid="input-user-class" /></div>
          )}
          {role === "siswa" && (
            <>
              <div><Label>No. HP Orang Tua</Label><Input value={parentPhone} onChange={e => setParentPhone(e.target.value)} placeholder="08xxxxxxxxxx" data-testid="input-user-parent-phone" /></div>
              <div><Label>Nama Orang Tua</Label><Input value={parentName} onChange={e => setParentName(e.target.value)} data-testid="input-user-parent-name" /></div>
            </>
          )}
          {(role === "guru" || role === "wali_kelas") && (
            <div><Label>No. HP / WhatsApp</Label><Input value={parentPhone} onChange={e => setParentPhone(e.target.value)} placeholder="08xxxxxxxxxx" data-testid="input-user-phone" /></div>
          )}
          <Button type="submit" className="w-full" data-testid="button-submit-user">Simpan</Button>
        </form>
      </DialogContent>
    </Dialog>
  );
}

function ManualAttendanceTab() {
  const { toast } = useToast();
  const { data: users } = useQuery<any[]>({ queryKey: ["/api/admin/users"] });
  const { data: classes } = useQuery<string[]>({ queryKey: ["/api/classes"] });
  const [filterClass, setFilterClass] = useState("");
  const [search, setSearch] = useState("");
  const [date, setDate] = useState(() => new Date().toISOString().split("T")[0]);
  const [selectedUser, setSelectedUser] = useState<any>(null);
  const [type, setType] = useState("checkin");
  const [time, setTime] = useState("");
  const [sendWa, setSendWa] = useState(true);

  const students = users?.filter(u => {
    if (u.role !== "siswa") return false;
    if (filterClass && filterClass !== "all" && u.className !== filterClass) return false;
    if (search) {
      const q = search.toLowerCase();
      return u.name?.toLowerCase().includes(q) || u.identifier?.toLowerCase().includes(q);
    }
    return true;
  }) || [];

  const manualMutation = useMutation({
    mutationFn: async (data: any) => {
      const res = await apiRequest("POST", "/api/admin/manual-attendance", data);
      return res.json();
    },
    onSuccess: (data: any) => {
      toast({ title: "Berhasil", description: data.message });
      setSelectedUser(null);
      setTime("");
    },
    onError: (err: any) => {
      toast({ title: "Gagal", description: err.message, variant: "destructive" });
    },
  });

  const handleSubmit = () => {
    if (!selectedUser) return;
    manualMutation.mutate({
      userId: selectedUser.id,
      date,
      type,
      time: time || undefined,
      sendWa,
    });
  };

  return (
    <div>
      <h2 className="text-2xl font-bold mb-4">Absen Manual</h2>
      <p className="text-sm text-muted-foreground mb-4">Gunakan fitur ini untuk mencatat kehadiran siswa yang lupa membawa kartu QR</p>

      <div className="grid gap-4 md:grid-cols-3">
        <div className="md:col-span-2">
          <Card>
            <CardHeader><CardTitle>Pilih Siswa</CardTitle></CardHeader>
            <CardContent className="space-y-3">
              <div className="flex gap-2">
                {classes && classes.length > 0 && (
                  <Select value={filterClass} onValueChange={setFilterClass}>
                    <SelectTrigger className="w-40" data-testid="select-manual-class"><SelectValue placeholder="Semua Kelas" /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">Semua Kelas</SelectItem>
                      {classes.map(c => <SelectItem key={c} value={c}>{c}</SelectItem>)}
                    </SelectContent>
                  </Select>
                )}
                <div className="relative flex-1">
                  <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                  <Input placeholder="Cari nama atau NISN..." value={search} onChange={e => setSearch(e.target.value)} className="pl-9" data-testid="input-manual-search" />
                </div>
              </div>
              <div className="border rounded-lg max-h-80 overflow-auto">
                <table className="w-full text-sm">
                  <thead className="bg-muted/50 sticky top-0">
                    <tr>
                      <th className="px-3 py-2 text-left">Nama</th>
                      <th className="px-3 py-2 text-left">NISN</th>
                      <th className="px-3 py-2 text-left">Kelas</th>
                      <th className="px-3 py-2 text-left">Aksi</th>
                    </tr>
                  </thead>
                  <tbody>
                    {students.map((s: any) => (
                      <tr key={s.id} className={`border-t cursor-pointer hover:bg-muted/50 ${selectedUser?.id === s.id ? "bg-primary/10" : ""}`} data-testid={`row-manual-student-${s.id}`}>
                        <td className="px-3 py-2 font-medium">{s.name}</td>
                        <td className="px-3 py-2 font-mono text-xs">{s.identifier}</td>
                        <td className="px-3 py-2">{s.className || "-"}</td>
                        <td className="px-3 py-2">
                          <Button size="sm" variant={selectedUser?.id === s.id ? "default" : "outline"} onClick={() => setSelectedUser(s)} data-testid={`button-select-student-${s.id}`}>
                            {selectedUser?.id === s.id ? "Dipilih" : "Pilih"}
                          </Button>
                        </td>
                      </tr>
                    ))}
                    {students.length === 0 && (
                      <tr><td colSpan={4} className="px-3 py-6 text-center text-muted-foreground">Tidak ada siswa ditemukan</td></tr>
                    )}
                  </tbody>
                </table>
              </div>
            </CardContent>
          </Card>
        </div>

        <div>
          <Card>
            <CardHeader><CardTitle>Input Absensi</CardTitle></CardHeader>
            <CardContent className="space-y-3">
              {selectedUser ? (
                <>
                  <div className="p-3 bg-muted rounded-lg text-center">
                    <p className="font-semibold" data-testid="text-selected-name">{selectedUser.name}</p>
                    <p className="text-xs text-muted-foreground">{selectedUser.identifier} - {selectedUser.className || "-"}</p>
                  </div>
                  <div>
                    <Label>Tanggal</Label>
                    <Input type="date" value={date} onChange={e => setDate(e.target.value)} data-testid="input-manual-date" />
                  </div>
                  <div>
                    <Label>Jenis Absensi</Label>
                    <Select value={type} onValueChange={setType}>
                      <SelectTrigger data-testid="select-manual-type"><SelectValue /></SelectTrigger>
                      <SelectContent>
                        <SelectItem value="checkin">Datang</SelectItem>
                        <SelectItem value="checkout">Pulang</SelectItem>
                        <SelectItem value="izin">Izin</SelectItem>
                        <SelectItem value="sakit">Sakit</SelectItem>
                        <SelectItem value="alpha">Alpha</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  {(type === "checkin" || type === "checkout") && (
                    <div>
                      <Label>Jam (opsional)</Label>
                      <Input type="time" value={time} onChange={e => setTime(e.target.value)} placeholder="Kosongkan untuk waktu sekarang" data-testid="input-manual-time" />
                      <p className="text-xs text-muted-foreground mt-1">Kosongkan untuk menggunakan waktu saat ini</p>
                    </div>
                  )}
                  <label className={`flex items-center gap-2 p-3 border rounded-lg cursor-pointer transition-colors ${sendWa ? "bg-green-50 border-green-300 dark:bg-green-950 dark:border-green-800" : "hover:bg-muted"}`} data-testid="toggle-send-wa">
                    <input type="checkbox" checked={sendWa} onChange={e => setSendWa(e.target.checked)} className="w-4 h-4 accent-green-600" />
                    <MessageSquare className="w-4 h-4 text-green-600" />
                    <div>
                      <span className={`text-sm font-medium ${sendWa ? "text-green-700 dark:text-green-400" : ""}`}>Kirim WA ke Orang Tua</span>
                      {selectedUser && !selectedUser.parentPhone && <p className="text-xs text-orange-500">No HP ortu belum diisi</p>}
                    </div>
                  </label>
                  <Button onClick={handleSubmit} className="w-full" disabled={manualMutation.isPending} data-testid="button-manual-submit">
                    <ClipboardEdit className="w-4 h-4 mr-2" />
                    {manualMutation.isPending ? "Memproses..." : "Simpan Absensi"}
                  </Button>
                </>
              ) : (
                <div className="text-center py-8 text-muted-foreground">
                  <ClipboardEdit className="w-10 h-10 mx-auto mb-2 opacity-40" />
                  <p>Pilih siswa terlebih dahulu dari daftar di samping</p>
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}


function printSingleQR(user: any) {
  const qrContainer = document.querySelector(`[data-testid="card-qr-${user.id}"] svg`);
  if (!qrContainer) {
    alert("QR Code tidak ditemukan. Pastikan QR sudah tampil di layar.");
    return;
  }
  if (!qrContainer.getAttribute("xmlns")) {
    qrContainer.setAttribute("xmlns", "http://www.w3.org/2000/svg");
  }
  const svgData = new XMLSerializer().serializeToString(qrContainer);
  const printWindow = window.open("", "_blank", "width=400,height=500");
  if (!printWindow) return;
  printWindow.document.write(`
    <html><head><title>QR Code - ${user.name}</title>
    <style>
      body{font-family:Arial,sans-serif;text-align:center;padding:40px;margin:0;}
      .qr-container{display:inline-block;padding:24px;border:2px solid #ccc;border-radius:12px;}
      .qr-container svg{width:200px;height:200px;}
      h2{margin:16px 0 4px;font-size:18px;}
      p{margin:2px 0;color:#666;font-size:13px;}
      @media print{body{padding:20px;}.qr-container{border:1px solid #999;}}
    </style>
    </head><body>
    <div class="qr-container">
      ${svgData}
      <h2>${user.name}</h2>
      <p>${user.identifier}</p>
      ${user.className ? `<p>${user.className}</p>` : ""}
    </div>
    <script>setTimeout(function(){ window.print(); }, 300);<\/script>
    </body></html>
  `);
  printWindow.document.close();
}

function QRCodesTab() {
  const [filterRole, setFilterRole] = useState("siswa");
  const [filterClass, setFilterClass] = useState("");
  const [search, setSearch] = useState("");
  const { data: users } = useQuery<any[]>({ queryKey: ["/api/admin/qrcodes"] });

  const filtered = users?.filter(u => {
    if (filterRole && u.role !== filterRole) return false;
    if (filterClass && filterClass !== "all" && u.className !== filterClass) return false;
    if (search) {
      const q = search.toLowerCase();
      return u.name?.toLowerCase().includes(q) || u.identifier?.toLowerCase().includes(q) || u.className?.toLowerCase().includes(q);
    }
    return true;
  }) || [];

  const classes = [...new Set(users?.filter(u => !filterRole || u.role === filterRole).map(u => u.className).filter(Boolean) || [])];

  return (
    <div>
      <div className="flex items-center justify-between mb-4 no-print">
        <h2 className="text-2xl font-bold">Cetak QR Code</h2>
        <Button onClick={() => window.print()} data-testid="button-print-qr"><Printer className="w-4 h-4 mr-2" />Print</Button>
      </div>
      <div className="flex gap-2 mb-4 no-print flex-wrap">
        <Select value={filterRole} onValueChange={setFilterRole}>
          <SelectTrigger className="w-32"><SelectValue /></SelectTrigger>
          <SelectContent>
            <SelectItem value="siswa">Siswa</SelectItem>
            <SelectItem value="guru">Guru</SelectItem>
            <SelectItem value="wali_kelas">Wali Kelas</SelectItem>
          </SelectContent>
        </Select>
        {classes.length > 0 && (
          <Select value={filterClass} onValueChange={setFilterClass}>
            <SelectTrigger className="w-40"><SelectValue placeholder="Semua Kelas" /></SelectTrigger>
            <SelectContent>
              <SelectItem value="all">Semua Kelas</SelectItem>
              {classes.map(c => <SelectItem key={c} value={c!}>{c}</SelectItem>)}
            </SelectContent>
          </Select>
        )}
        <div className="relative flex-1 min-w-[200px]">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
          <Input
            placeholder="Cari nama, NISN/NIP, atau kelas..."
            value={search}
            onChange={e => setSearch(e.target.value)}
            className="pl-9"
            data-testid="input-search-qr"
          />
        </div>
      </div>
      {search && <p className="text-sm text-muted-foreground mb-3 no-print" data-testid="text-search-count">Menampilkan {filtered.length} hasil untuk "{search}"</p>}
      <div className="border rounded-lg overflow-auto">
        <table className="w-full text-sm">
          <thead className="bg-muted/50 sticky top-0">
            <tr>
              <th className="px-3 py-2 text-left text-xs">#</th>
              <th className="px-3 py-2 text-left text-xs">Nama</th>
              <th className="px-3 py-2 text-left text-xs">NISN/NIP</th>
              <th className="px-3 py-2 text-left text-xs">Kelas</th>
              <th className="px-3 py-2 text-center text-xs">QR Code</th>
              <th className="px-3 py-2 text-center text-xs no-print">Aksi</th>
            </tr>
          </thead>
          <tbody>
            {filtered.map((u: any, i: number) => (
              <tr key={u.id} className="border-t" data-testid={`card-qr-${u.id}`}>
                <td className="px-3 py-2 text-xs text-muted-foreground">{i + 1}</td>
                <td className="px-3 py-2 text-xs font-medium">{u.name}</td>
                <td className="px-3 py-2 text-xs text-muted-foreground">{u.identifier}</td>
                <td className="px-3 py-2 text-xs text-muted-foreground">{u.className || "-"}</td>
                <td className="px-3 py-2 text-center">
                  <div className="bg-white p-1 rounded inline-block">
                    <QRCode value={u.qrCode} size={60} />
                  </div>
                </td>
                <td className="px-3 py-2 text-center no-print">
                  <Button size="sm" variant="outline" onClick={() => printSingleQR(u)} data-testid={`button-print-single-${u.id}`}>
                    <Printer className="w-3 h-3 mr-1" />Cetak
                  </Button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}

function RecapTab() {
  const [startDate, setStartDate] = useState("");
  const [endDate, setEndDate] = useState("");
  const [filterClass, setFilterClass] = useState("");
  const [filterRole, setFilterRole] = useState("");
  const [filterStatus, setFilterStatus] = useState("");

  const queryParams = new URLSearchParams();
  if (startDate) queryParams.set("startDate", startDate);
  if (endDate) queryParams.set("endDate", endDate);
  if (filterClass) queryParams.set("className", filterClass);
  if (filterRole) queryParams.set("role", filterRole);
  if (filterStatus) queryParams.set("status", filterStatus);

  const { data: records, isLoading } = useQuery<any[]>({
    queryKey: ["/api/admin/attendance", `?${queryParams.toString()}`],
    enabled: !!(startDate || endDate),
  });

  const stats = {
    hadir: records?.filter(r => r.status === "hadir").length || 0,
    telat: records?.filter(r => r.status === "telat").length || 0,
    izin: records?.filter(r => r.status === "izin").length || 0,
    sakit: records?.filter(r => r.status === "sakit").length || 0,
    alpha: records?.filter(r => r.status === "alpha").length || 0,
  };

  const handleExport = () => {
    const params = new URLSearchParams();
    if (startDate) params.set("startDate", startDate);
    if (endDate) params.set("endDate", endDate);
    if (filterClass) params.set("className", filterClass);
    if (filterRole) params.set("role", filterRole);
    if (filterStatus) params.set("status", filterStatus);
    window.open(`/api/admin/attendance/export?${params.toString()}`);
  };

  return (
    <div>
      <div className="flex items-center justify-between mb-4">
        <h2 className="text-2xl font-bold">Rekap Absensi</h2>
        <Button onClick={handleExport} variant="outline" data-testid="button-export-csv"><Download className="w-4 h-4 mr-2" />Export CSV</Button>
      </div>

      <Card className="mb-4">
        <CardContent className="p-4">
          <div className="grid grid-cols-2 md:grid-cols-5 gap-2">
            <div><Label>Dari Tanggal</Label><Input type="date" value={startDate} onChange={e => setStartDate(e.target.value)} data-testid="input-start-date" /></div>
            <div><Label>Sampai Tanggal</Label><Input type="date" value={endDate} onChange={e => setEndDate(e.target.value)} data-testid="input-end-date" /></div>
            <div>
              <Label>Kelas</Label>
              <Input placeholder="Kelas" value={filterClass} onChange={e => setFilterClass(e.target.value)} data-testid="input-filter-class" />
            </div>
            <div>
              <Label>Role</Label>
              <Select value={filterRole || "all"} onValueChange={v => setFilterRole(v === "all" ? "" : v)}>
                <SelectTrigger data-testid="select-filter-recap-role"><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">Semua</SelectItem>
                  <SelectItem value="siswa">Siswa</SelectItem>
                  <SelectItem value="guru">Guru</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label>Status</Label>
              <Select value={filterStatus || "all"} onValueChange={v => setFilterStatus(v === "all" ? "" : v)}>
                <SelectTrigger data-testid="select-filter-status"><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">Semua</SelectItem>
                  <SelectItem value="hadir">Hadir</SelectItem>
                  <SelectItem value="telat">Telat</SelectItem>
                  <SelectItem value="izin">Izin</SelectItem>
                  <SelectItem value="sakit">Sakit</SelectItem>
                  <SelectItem value="alpha">Alpha</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
        </CardContent>
      </Card>

      {records && records.length > 0 && (
        <div className="grid grid-cols-5 gap-2 mb-4">
          <Card><CardContent className="p-3 text-center"><p className="text-xs text-muted-foreground">Hadir</p><p className="text-xl font-bold text-green-600">{stats.hadir}</p></CardContent></Card>
          <Card><CardContent className="p-3 text-center"><p className="text-xs text-muted-foreground">Telat</p><p className="text-xl font-bold text-orange-600">{stats.telat}</p></CardContent></Card>
          <Card><CardContent className="p-3 text-center"><p className="text-xs text-muted-foreground">Izin</p><p className="text-xl font-bold text-blue-600">{stats.izin}</p></CardContent></Card>
          <Card><CardContent className="p-3 text-center"><p className="text-xs text-muted-foreground">Sakit</p><p className="text-xl font-bold text-yellow-600">{stats.sakit}</p></CardContent></Card>
          <Card><CardContent className="p-3 text-center"><p className="text-xs text-muted-foreground">Alpha</p><p className="text-xl font-bold text-red-600">{stats.alpha}</p></CardContent></Card>
        </div>
      )}

      <div className="border rounded-lg overflow-auto">
        <table className="w-full text-sm">
          <thead className="bg-muted/50">
            <tr>
              <th className="px-3 py-2 text-left">No</th>
              <th className="px-3 py-2 text-left">Tanggal</th>
              <th className="px-3 py-2 text-left">Nama</th>
              <th className="px-3 py-2 text-left">NISN/NIP</th>
              <th className="px-3 py-2 text-left">Kelas</th>
              <th className="px-3 py-2 text-left">Jam Datang</th>
              <th className="px-3 py-2 text-left">Jam Pulang</th>
              <th className="px-3 py-2 text-left">Status</th>
            </tr>
          </thead>
          <tbody>
            {isLoading ? (
              <tr><td colSpan={8} className="px-3 py-8 text-center text-muted-foreground">Memuat...</td></tr>
            ) : records && records.length > 0 ? (
              records.map((r: any, i: number) => (
                <tr key={r.id} className="border-t" data-testid={`row-attendance-${r.id}`}>
                  <td className="px-3 py-2">{i + 1}</td>
                  <td className="px-3 py-2">{r.date}</td>
                  <td className="px-3 py-2">{r.user?.name}</td>
                  <td className="px-3 py-2 font-mono text-xs">{r.user?.identifier}</td>
                  <td className="px-3 py-2">{r.user?.className || "-"}</td>
                  <td className="px-3 py-2">{r.checkInTime || "-"}</td>
                  <td className="px-3 py-2">{r.checkOutTime || "-"}</td>
                  <td className="px-3 py-2">
                    <Badge variant={r.status === "hadir" ? "default" : r.status === "telat" ? "secondary" : "destructive"} className={r.status === "telat" ? "bg-orange-100 text-orange-700 dark:bg-orange-900 dark:text-orange-300" : ""}>{r.status}</Badge>
                  </td>
                </tr>
              ))
            ) : (
              <tr><td colSpan={8} className="px-3 py-8 text-center text-muted-foreground">
                {startDate || endDate ? "Tidak ada data" : "Pilih rentang tanggal untuk melihat data"}
              </td></tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
}
