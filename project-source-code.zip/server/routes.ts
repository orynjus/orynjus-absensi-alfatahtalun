import type { Express, Request, Response, NextFunction } from "express";
import { createServer, type Server } from "http";
import session from "express-session";
import connectPgSimple from "connect-pg-simple";
import multer from "multer";
import { storage } from "./storage";
import { loginSchema, insertUserSchema, insertHolidaySchema } from "@shared/schema";
import { appendAttendanceRow, updateAttendanceRow, initSheetHeaders, readUsersFromSheet, getSheetTabs } from "./googleSheets";
import { uploadExcusePhoto } from "./googleDrive";
import { sendCheckInNotification, sendLateNotification, sendCheckOutNotification, sendManualAttendanceNotification, sendExcuseNotificationToHomeroom } from "./fonnte";
import crypto from "crypto";

const upload = multer({ storage: multer.memoryStorage(), limits: { fileSize: 5 * 1024 * 1024 } });

declare module "express-session" {
  interface SessionData {
    userId: number;
    role: string;
  }
}

function requireAuth(req: Request, res: Response, next: NextFunction) {
  if (!req.session.userId) {
    return res.status(401).json({ message: "Unauthorized" });
  }
  next();
}

function requireRole(...roles: string[]) {
  return (req: Request, res: Response, next: NextFunction) => {
    if (!req.session.userId) {
      return res.status(401).json({ message: "Unauthorized" });
    }
    if (!roles.includes(req.session.role!)) {
      return res.status(403).json({ message: "Forbidden" });
    }
    next();
  };
}

function getCurrentDate(): string {
  const now = new Date();
  const offset = 7 * 60;
  const wib = new Date(now.getTime() + (offset + now.getTimezoneOffset()) * 60000);
  return wib.toISOString().split('T')[0];
}

function getCurrentTime(): string {
  const now = new Date();
  const offset = 7 * 60;
  const wib = new Date(now.getTime() + (offset + now.getTimezoneOffset()) * 60000);
  return wib.toTimeString().slice(0, 5);
}

function isTimeInRange(current: string, start: string, end: string): boolean {
  return current >= start && current <= end;
}

function getCurrentDayOfWeek(): number {
  const now = new Date();
  const offset = 7 * 60;
  const wib = new Date(now.getTime() + (offset + now.getTimezoneOffset()) * 60000);
  return wib.getDay();
}

const DAY_NAMES = ["minggu", "senin", "selasa", "rabu", "kamis", "jumat", "sabtu"];

function getDaySchedule(settings: any): { checkInStart: string; checkInEnd: string; checkOutStart: string; checkOutEnd: string; enabled: boolean } {
  const dayIndex = getCurrentDayOfWeek();
  const dayName = DAY_NAMES[dayIndex];
  if (settings.weeklySchedule) {
    try {
      const weekly = JSON.parse(settings.weeklySchedule);
      if (weekly[dayName]) {
        return {
          checkInStart: weekly[dayName].checkInStart || settings.checkInStart,
          checkInEnd: weekly[dayName].checkInEnd || settings.checkInEnd,
          checkOutStart: weekly[dayName].checkOutStart || settings.checkOutStart,
          checkOutEnd: weekly[dayName].checkOutEnd || settings.checkOutEnd,
          enabled: weekly[dayName].enabled !== false,
        };
      }
    } catch {}
  }
  return {
    checkInStart: settings.checkInStart,
    checkInEnd: settings.checkInEnd,
    checkOutStart: settings.checkOutStart,
    checkOutEnd: settings.checkOutEnd,
    enabled: true,
  };
}

function isDefaultHoliday(settings: any): boolean {
  const dayIndex = getCurrentDayOfWeek();
  const defaultDays = (settings.defaultHolidayDays || "0,6").split(",").map((d: string) => parseInt(d.trim()));
  return defaultDays.includes(dayIndex);
}

async function seedData() {
  const adminExists = await storage.getUserByIdentifier("admin");
  if (!adminExists) {
    await storage.createUser({
      name: "Administrator",
      identifier: "admin",
      password: "admin123",
      role: "admin",
      className: null,
      parentPhone: null,
      parentName: null,
      qrCode: crypto.randomUUID(),
    });
    console.log("Default admin created (admin/admin123)");
  }

  const sampleStudent = await storage.getUserByIdentifier("1234567890");
  if (!sampleStudent) {
    await storage.createUser({
      name: "Budi Santoso",
      identifier: "1234567890",
      password: "1234567890",
      role: "siswa",
      className: "XII-IPA-1",
      parentPhone: "08123456789",
      parentName: "Pak Santoso",
      qrCode: crypto.randomUUID(),
    });
    await storage.createUser({
      name: "Siti Rahayu",
      identifier: "1234567891",
      password: "1234567891",
      role: "siswa",
      className: "XII-IPA-1",
      parentPhone: "08123456780",
      parentName: "Bu Rahayu",
      qrCode: crypto.randomUUID(),
    });
    await storage.createUser({
      name: "Ahmad Fauzi",
      identifier: "198501012010",
      password: "198501012010",
      role: "guru",
      className: null,
      parentPhone: null,
      parentName: null,
      qrCode: crypto.randomUUID(),
    });
    await storage.createUser({
      name: "Dewi Lestari",
      identifier: "198602022011",
      password: "198602022011",
      role: "wali_kelas",
      className: "XII-IPA-1",
      parentPhone: null,
      parentName: null,
      qrCode: crypto.randomUUID(),
    });
    console.log("Sample users seeded");
  }
}

export async function registerRoutes(
  httpServer: Server,
  app: Express
): Promise<Server> {
  const PgSession = connectPgSimple(session);

  app.use(
    session({
      store: new PgSession({
        conString: process.env.DATABASE_URL,
        createTableIfMissing: true,
      }),
      secret: process.env.SESSION_SECRET || "attendance-secret-key",
      resave: false,
      saveUninitialized: false,
      cookie: {
        maxAge: 24 * 60 * 60 * 1000,
        httpOnly: true,
        secure: false,
        sameSite: "lax",
      },
    })
  );

  await seedData();
  initSheetHeaders().catch(console.error);

  // AUTH ROUTES
  app.post("/api/auth/login", async (req: Request, res: Response) => {
    try {
      const parsed = loginSchema.safeParse(req.body);
      if (!parsed.success) {
        return res.status(400).json({ message: "Data login tidak valid" });
      }
      const { identifier, password, role } = parsed.data;
      const user = await storage.getUserByIdentifier(identifier);

      if (!user || user.role !== role) {
        return res.status(401).json({ message: "Identifier atau role tidak ditemukan" });
      }

      if (role === "siswa" || role === "guru" || role === "wali_kelas") {
        if (user.identifier !== password) {
          return res.status(401).json({ message: "Password salah" });
        }
      } else {
        if (user.password !== password) {
          return res.status(401).json({ message: "Password salah" });
        }
      }

      req.session.userId = user.id;
      req.session.role = user.role;
      const { password: _, ...safeUser } = user;
      res.json({ user: safeUser });
    } catch (error) {
      console.error("Login error:", error);
      res.status(500).json({ message: "Server error" });
    }
  });

  app.post("/api/auth/logout", (req: Request, res: Response) => {
    req.session.destroy((err) => {
      if (err) return res.status(500).json({ message: "Logout failed" });
      res.json({ message: "Logged out" });
    });
  });

  app.get("/api/auth/me", async (req: Request, res: Response) => {
    if (!req.session.userId) {
      return res.status(401).json({ message: "Not authenticated" });
    }
    const user = await storage.getUser(req.session.userId);
    if (!user) {
      return res.status(401).json({ message: "User not found" });
    }
    const { password: _, ...safeUser } = user;
    res.json({ user: safeUser });
  });

  // SCANNER ROUTES
  app.get("/api/scanner/status", async (_req: Request, res: Response) => {
    try {
      const settings = await storage.getScannerSettings();
      const currentTime = getCurrentTime();
      const currentDate = getCurrentDate();
      const holiday = await storage.getHolidayByDate(currentDate);
      const defaultHoliday = isDefaultHoliday(settings);
      const daySchedule = getDaySchedule(settings);

      let scanWindow: "checkin" | "checkout" | "closed" = "closed";
      if (!settings.isLocked && !holiday && !defaultHoliday && daySchedule.enabled) {
        if (isTimeInRange(currentTime, daySchedule.checkInStart, daySchedule.checkInEnd)) {
          scanWindow = "checkin";
        } else if (isTimeInRange(currentTime, daySchedule.checkOutStart, daySchedule.checkOutEnd)) {
          scanWindow = "checkout";
        }
      }

      const dayName = DAY_NAMES[getCurrentDayOfWeek()];

      res.json({
        isLocked: settings.isLocked,
        scanWindow,
        isHoliday: !!holiday || defaultHoliday,
        holidayDescription: holiday?.description || (defaultHoliday ? `Libur ${dayName.charAt(0).toUpperCase() + dayName.slice(1)}` : null),
        checkInStart: daySchedule.checkInStart,
        checkInEnd: daySchedule.checkInEnd,
        checkOutStart: daySchedule.checkOutStart,
        checkOutEnd: daySchedule.checkOutEnd,
        lateThreshold: settings.lateThreshold,
        currentTime,
        currentDate,
        currentDay: dayName,
        dayEnabled: daySchedule.enabled,
      });
    } catch (error) {
      console.error("Scanner status error:", error);
      res.status(500).json({ message: "Server error" });
    }
  });

  app.put("/api/scanner/settings", requireRole("admin"), async (req: Request, res: Response) => {
    try {
      const { isLocked, checkInStart, checkInEnd, checkOutStart, checkOutEnd, lockPin, lateThreshold, weeklySchedule, defaultHolidayDays, fonnteToken, googleSheetId, googleDriveFolderId } = req.body;
      const updateData: any = {};
      if (isLocked !== undefined) updateData.isLocked = isLocked;
      if (checkInStart) updateData.checkInStart = checkInStart;
      if (checkInEnd) updateData.checkInEnd = checkInEnd;
      if (checkOutStart) updateData.checkOutStart = checkOutStart;
      if (checkOutEnd) updateData.checkOutEnd = checkOutEnd;
      if (lockPin) updateData.lockPin = lockPin;
      if (lateThreshold) updateData.lateThreshold = lateThreshold;
      if (weeklySchedule !== undefined) updateData.weeklySchedule = typeof weeklySchedule === "string" ? weeklySchedule : JSON.stringify(weeklySchedule);
      if (defaultHolidayDays !== undefined) updateData.defaultHolidayDays = defaultHolidayDays;
      if (fonnteToken !== undefined) updateData.fonnteToken = fonnteToken || null;
      if (googleSheetId !== undefined) updateData.googleSheetId = googleSheetId || null;
      if (googleDriveFolderId !== undefined) updateData.googleDriveFolderId = googleDriveFolderId || null;
      const updated = await storage.updateScannerSettings(updateData);
      res.json(updated);
    } catch (error) {
      console.error("Scanner settings error:", error);
      res.status(500).json({ message: "Server error" });
    }
  });

  app.get("/api/scanner/full-settings", requireRole("admin"), async (_req: Request, res: Response) => {
    try {
      const settings = await storage.getScannerSettings();
      res.json(settings);
    } catch (error) {
      res.status(500).json({ message: "Server error" });
    }
  });

  app.post("/api/scanner/toggle-pin", async (req: Request, res: Response) => {
    try {
      const { pin } = req.body;
      if (!pin) {
        return res.status(400).json({ message: "PIN diperlukan" });
      }
      const settings = await storage.getScannerSettings();
      if (pin !== settings.lockPin) {
        return res.status(401).json({ message: "PIN salah" });
      }
      const updated = await storage.updateScannerSettings({ isLocked: !settings.isLocked });
      res.json({ isLocked: updated.isLocked, message: updated.isLocked ? "Scanner dikunci" : "Scanner dibuka" });
    } catch (error) {
      console.error("Scanner toggle error:", error);
      res.status(500).json({ message: "Server error" });
    }
  });

  // SCAN QR CODE
  app.post("/api/scan", async (req: Request, res: Response) => {
    try {
      const { qrCode } = req.body;
      if (!qrCode) {
        return res.status(400).json({ success: false, message: "QR code tidak valid" });
      }

      const settings = await storage.getScannerSettings();
      if (settings.isLocked) {
        return res.status(403).json({ success: false, message: "Scanner dikunci oleh admin" });
      }

      const currentDate = getCurrentDate();
      const currentTime = getCurrentTime();

      if (isDefaultHoliday(settings)) {
        const dayName = DAY_NAMES[getCurrentDayOfWeek()];
        return res.status(403).json({ success: false, message: `Hari libur: Libur ${dayName.charAt(0).toUpperCase() + dayName.slice(1)}` });
      }

      const holiday = await storage.getHolidayByDate(currentDate);
      if (holiday) {
        return res.status(403).json({ success: false, message: `Hari libur: ${holiday.description}` });
      }

      const daySchedule = getDaySchedule(settings);
      if (!daySchedule.enabled) {
        return res.status(403).json({ success: false, message: "Scanner tidak aktif pada hari ini" });
      }

      let scanType: "checkin" | "checkout" | null = null;
      if (isTimeInRange(currentTime, daySchedule.checkInStart, daySchedule.checkInEnd)) {
        scanType = "checkin";
      } else if (isTimeInRange(currentTime, daySchedule.checkOutStart, daySchedule.checkOutEnd)) {
        scanType = "checkout";
      }

      if (!scanType) {
        return res.status(403).json({
          success: false,
          message: `Di luar jadwal scan. Check-in: ${daySchedule.checkInStart}-${daySchedule.checkInEnd}, Check-out: ${daySchedule.checkOutStart}-${daySchedule.checkOutEnd}`
        });
      }

      const user = await storage.getUserByQrCode(qrCode);
      if (!user) {
        return res.status(404).json({ success: false, message: "QR code tidak terdaftar" });
      }

      const existing = await storage.getAttendance(user.id, currentDate);

      if (scanType === "checkin") {
        if (existing && existing.checkInTime) {
          return res.status(409).json({
            success: false,
            message: `${user.name} sudah absen datang hari ini (${existing.checkInTime})`
          });
        }

        const threshold = settings.lateThreshold || "07:15";
        const isLate = currentTime > threshold;
        const checkInStatus = isLate ? "telat" : "hadir";

        if (existing) {
          await storage.updateAttendance(existing.id, { checkInTime: currentTime, status: checkInStatus });
        } else {
          await storage.createAttendance({
            userId: user.id,
            date: currentDate,
            checkInTime: currentTime,
            checkOutTime: null,
            status: checkInStatus,
          });
        }

        if (user.role === "siswa" && user.parentPhone) {
          if (isLate) {
            sendLateNotification(user.parentPhone, user.name, currentTime).catch(console.error);
          } else {
            sendCheckInNotification(user.parentPhone, user.name, currentTime).catch(console.error);
          }
        }

        appendAttendanceRow({
          date: currentDate,
          name: user.name,
          identifier: user.identifier,
          className: user.className || "-",
          checkInTime: currentTime,
          checkOutTime: "-",
          status: checkInStatus,
          role: user.role,
        }).catch(console.error);

        return res.json({
          success: true,
          type: "datang",
          name: user.name,
          time: currentTime,
          className: user.className,
          status: checkInStatus,
          message: `${user.name} - ${isLate ? "Terlambat" : "Absen Datang"} ${currentTime}`,
        });
      }

      if (scanType === "checkout") {
        if (!existing || !existing.checkInTime) {
          return res.status(400).json({
            success: false,
            message: `${user.name} belum absen datang hari ini`
          });
        }
        if (existing.checkOutTime) {
          return res.status(409).json({
            success: false,
            message: `${user.name} sudah absen pulang hari ini (${existing.checkOutTime})`
          });
        }

        await storage.updateAttendance(existing.id, { checkOutTime: currentTime });

        if (user.role === "siswa" && user.parentPhone) {
          sendCheckOutNotification(user.parentPhone, user.name, currentTime).catch(console.error);
        }

        updateAttendanceRow(currentDate, user.identifier, currentTime, "pulang").catch(console.error);

        return res.json({
          success: true,
          type: "pulang",
          name: user.name,
          time: currentTime,
          className: user.className,
          message: `${user.name} - Absen Pulang ${currentTime}`,
        });
      }
    } catch (error) {
      console.error("Scan error:", error);
      res.status(500).json({ success: false, message: "Server error" });
    }
  });

  // MANUAL ATTENDANCE (admin)
  app.post("/api/admin/manual-attendance", requireRole("admin"), async (req: Request, res: Response) => {
    try {
      const { userId, date, type, time, sendWa } = req.body;
      if (!userId || !date || !type) {
        return res.status(400).json({ message: "Data tidak lengkap" });
      }
      const targetUser = await storage.getUser(userId);
      if (!targetUser) {
        return res.status(404).json({ message: "User tidak ditemukan" });
      }
      const existing = await storage.getAttendance(userId, date);
      const settings = await storage.getScannerSettings();
      const currentTime = time || getCurrentTime();
      let responseMessage = "";
      let waType = type;

      if (type === "checkin") {
        if (existing && existing.checkInTime) {
          return res.status(409).json({ message: `${targetUser.name} sudah absen datang pada ${date}` });
        }
        const threshold = settings.lateThreshold || "07:15";
        const isLate = currentTime > threshold;
        const status = isLate ? "telat" : "hadir";
        if (isLate) waType = "telat";
        if (existing) {
          await storage.updateAttendance(existing.id, { checkInTime: currentTime, status });
        } else {
          await storage.createAttendance({ userId, date, checkInTime: currentTime, checkOutTime: null, status });
        }
        appendAttendanceRow({ date, name: targetUser.name, identifier: targetUser.identifier, className: targetUser.className || "-", checkInTime: currentTime, checkOutTime: "-", status, role: targetUser.role }).catch(console.error);
        responseMessage = `${targetUser.name} - Absen Datang Manual (${currentTime})${isLate ? " [Telat]" : ""}`;
      } else if (type === "checkout") {
        if (!existing || !existing.checkInTime) {
          return res.status(400).json({ message: `${targetUser.name} belum absen datang pada ${date}` });
        }
        if (existing.checkOutTime) {
          return res.status(409).json({ message: `${targetUser.name} sudah absen pulang pada ${date}` });
        }
        await storage.updateAttendance(existing.id, { checkOutTime: currentTime });
        updateAttendanceRow(date, targetUser.identifier, currentTime, "pulang").catch(console.error);
        responseMessage = `${targetUser.name} - Absen Pulang Manual (${currentTime})`;
      } else if (type === "izin" || type === "sakit" || type === "alpha") {
        if (existing) {
          await storage.updateAttendance(existing.id, { status: type });
        } else {
          await storage.createAttendance({ userId, date, checkInTime: null, checkOutTime: null, status: type });
        }
        appendAttendanceRow({ date, name: targetUser.name, identifier: targetUser.identifier, className: targetUser.className || "-", checkInTime: "-", checkOutTime: "-", status: type, role: targetUser.role }).catch(console.error);
        responseMessage = `${targetUser.name} - Status ${type} (${date})`;
      } else {
        return res.status(400).json({ message: "Tipe absensi tidak valid" });
      }

      let waSent = false;
      if (sendWa && targetUser.role === "siswa" && targetUser.parentPhone) {
        if (waType === "telat") {
          waSent = await sendLateNotification(targetUser.parentPhone, targetUser.name, currentTime).catch(() => false) as boolean;
        } else {
          const timeForWa = (type === "checkin" || type === "checkout") ? currentTime : undefined;
          waSent = await sendManualAttendanceNotification(targetUser.parentPhone, targetUser.name, waType, date, timeForWa).catch(() => false) as boolean;
        }
        if (waSent) responseMessage += " | WA terkirim";
        else responseMessage += " | WA gagal terkirim";
      } else if (sendWa && targetUser.role === "siswa" && !targetUser.parentPhone) {
        responseMessage += " | No HP ortu belum diisi";
      }

      return res.json({ success: true, message: responseMessage, waSent });
    } catch (error) {
      console.error("Manual attendance error:", error);
      res.status(500).json({ message: "Server error" });
    }
  });

  // HOLIDAYS
  app.get("/api/holidays", async (_req: Request, res: Response) => {
    const list = await storage.getHolidays();
    res.json(list);
  });

  app.post("/api/holidays", requireRole("admin"), async (req: Request, res: Response) => {
    try {
      const parsed = insertHolidaySchema.safeParse(req.body);
      if (!parsed.success) {
        return res.status(400).json({ message: "Data tidak valid" });
      }
      const holiday = await storage.createHoliday(parsed.data);
      res.json(holiday);
    } catch (error) {
      console.error("Create holiday error:", error);
      res.status(500).json({ message: "Server error" });
    }
  });

  app.delete("/api/holidays/:id", requireRole("admin"), async (req: Request, res: Response) => {
    await storage.deleteHoliday(parseInt(req.params.id));
    res.json({ message: "Deleted" });
  });

  // ADMIN ROUTES
  app.get("/api/admin/users", requireRole("admin"), async (req: Request, res: Response) => {
    const { role, className } = req.query;
    const list = await storage.getUsers(role as string | undefined, className as string | undefined);
    const safeList = list.map(({ password, ...u }) => u);
    res.json(safeList);
  });

  app.post("/api/admin/users", requireRole("admin"), async (req: Request, res: Response) => {
    try {
      const { name, identifier, role, className, parentPhone, parentName } = req.body;
      if (!name || !identifier || !role) {
        return res.status(400).json({ message: "Data tidak lengkap" });
      }

      const existingUser = await storage.getUserByIdentifier(identifier);
      if (existingUser) {
        return res.status(409).json({ message: "Identifier sudah digunakan" });
      }

      const user = await storage.createUser({
        name,
        identifier,
        password: role === "admin" ? req.body.password || identifier : identifier,
        role,
        className: className || null,
        parentPhone: parentPhone || null,
        parentName: parentName || null,
        qrCode: crypto.randomUUID(),
      });
      const { password: _, ...safeUser } = user;
      res.json(safeUser);
    } catch (error) {
      console.error("Create user error:", error);
      res.status(500).json({ message: "Server error" });
    }
  });

  app.put("/api/admin/users/:id", requireRole("admin"), async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      const { name, identifier, role, className, parentPhone, parentName } = req.body;
      const updated = await storage.updateUser(id, {
        name, identifier, role, className, parentPhone, parentName,
      });
      if (!updated) {
        return res.status(404).json({ message: "User not found" });
      }
      const { password: _, ...safeUser } = updated;
      res.json(safeUser);
    } catch (error) {
      console.error("Update user error:", error);
      res.status(500).json({ message: "Server error" });
    }
  });

  app.delete("/api/admin/users/:id", requireRole("admin"), async (req: Request, res: Response) => {
    await storage.deleteUser(parseInt(req.params.id));
    res.json({ message: "Deleted" });
  });

  app.get("/api/admin/sheet-tabs", requireRole("admin"), async (_req: Request, res: Response) => {
    try {
      const tabs = await getSheetTabs();
      res.json({ tabs });
    } catch (error: any) {
      console.error("Failed to get sheet tabs:", error);
      res.status(500).json({ message: "Gagal membaca Google Sheet: " + error.message });
    }
  });

  const ALLOWED_IMPORT_TABS = ["Siswa", "Guru", "Wali Kelas"];

  app.get("/api/admin/sheet-preview", requireRole("admin"), async (req: Request, res: Response) => {
    try {
      const tab = req.query.tab as string;
      if (!tab || !ALLOWED_IMPORT_TABS.includes(tab)) return res.status(400).json({ message: "Tab tidak valid. Gunakan: Siswa, Guru, atau Wali Kelas" });
      const rows = await readUsersFromSheet(tab);
      res.json({ rows, tab });
    } catch (error: any) {
      console.error("Failed to read sheet:", error);
      res.status(500).json({ message: "Gagal membaca data dari sheet: " + error.message });
    }
  });

  app.post("/api/admin/import-users", requireRole("admin"), async (req: Request, res: Response) => {
    try {
      const { tab } = req.body;
      if (!tab || !ALLOWED_IMPORT_TABS.includes(tab)) return res.status(400).json({ message: "Tab tidak valid. Gunakan: Siswa, Guru, atau Wali Kelas" });

      const rows = await readUsersFromSheet(tab);
      if (rows.length === 0) {
        return res.status(400).json({ message: "Sheet kosong, tidak ada data untuk diimport" });
      }

      let imported = 0;
      let skipped = 0;
      let errors: string[] = [];

      const tabLower = tab.toLowerCase();

      for (let i = 0; i < rows.length; i++) {
        const row = rows[i];
        try {
          if (tabLower === "siswa") {
            const [name, nisn, className, parentPhone, parentName] = row;
            if (!name || !nisn) { skipped++; errors.push(`Baris ${i + 2}: Nama atau NISN kosong`); continue; }
            const existing = await storage.getUserByIdentifier(nisn);
            if (existing) { skipped++; errors.push(`Baris ${i + 2}: NISN ${nisn} sudah terdaftar`); continue; }
            await storage.createUser({
              name: name.trim(),
              identifier: nisn.trim(),
              password: nisn.trim(),
              role: "siswa",
              className: className?.trim() || null,
              parentPhone: parentPhone?.trim() || null,
              parentName: parentName?.trim() || null,
              qrCode: crypto.randomUUID(),
            });
            imported++;
          } else if (tabLower === "guru") {
            const [name, nip, phone] = row;
            if (!name || !nip) { skipped++; errors.push(`Baris ${i + 2}: Nama atau NIP kosong`); continue; }
            const existing = await storage.getUserByIdentifier(nip);
            if (existing) { skipped++; errors.push(`Baris ${i + 2}: NIP ${nip} sudah terdaftar`); continue; }
            await storage.createUser({
              name: name.trim(),
              identifier: nip.trim(),
              password: nip.trim(),
              role: "guru",
              className: null,
              parentPhone: phone?.trim() || null,
              parentName: null,
              qrCode: crypto.randomUUID(),
            });
            imported++;
          } else if (tabLower === "wali kelas") {
            const [name, nip, className, phone] = row;
            if (!name || !nip) { skipped++; errors.push(`Baris ${i + 2}: Nama atau NIP kosong`); continue; }
            const existing = await storage.getUserByIdentifier(nip);
            if (existing) { skipped++; errors.push(`Baris ${i + 2}: NIP ${nip} sudah terdaftar`); continue; }
            await storage.createUser({
              name: name.trim(),
              identifier: nip.trim(),
              password: nip.trim(),
              role: "wali_kelas",
              className: className?.trim() || null,
              parentPhone: phone?.trim() || null,
              parentName: null,
              qrCode: crypto.randomUUID(),
            });
            imported++;
          } else {
            return res.status(400).json({ message: `Tab "${tab}" tidak dikenali. Gunakan tab: Siswa, Guru, atau Wali Kelas` });
          }
        } catch (err: any) {
          skipped++;
          errors.push(`Baris ${i + 2}: ${err.message}`);
        }
      }

      res.json({ imported, skipped, errors: errors.slice(0, 20), total: rows.length });
    } catch (error: any) {
      console.error("Import users error:", error);
      res.status(500).json({ message: "Gagal import data: " + error.message });
    }
  });

  app.get("/api/admin/attendance", requireRole("admin"), async (req: Request, res: Response) => {
    const { startDate, endDate, className, role, status } = req.query;
    const records = await storage.getAttendanceFiltered({
      startDate: startDate as string | undefined,
      endDate: endDate as string | undefined,
      className: className as string | undefined,
      role: role as string | undefined,
      status: status as string | undefined,
    });
    res.json(records);
  });

  app.get("/api/admin/attendance/export", requireRole("admin"), async (req: Request, res: Response) => {
    const { startDate, endDate, className, role, status } = req.query;
    const records = await storage.getAttendanceFiltered({
      startDate: startDate as string | undefined,
      endDate: endDate as string | undefined,
      className: className as string | undefined,
      role: role as string | undefined,
      status: status as string | undefined,
    });

    const csvHeader = "No,Tanggal,Nama,NISN/NIP,Kelas,Jam Datang,Jam Pulang,Status\n";
    const csvRows = records.map((r, i) =>
      `${i + 1},"${r.date}","${r.user.name}","${r.user.identifier}","${r.user.className || '-'}","${r.checkInTime || '-'}","${r.checkOutTime || '-'}","${r.status}"`
    ).join("\n");

    res.setHeader('Content-Type', 'text/csv; charset=utf-8');
    res.setHeader('Content-Disposition', 'attachment; filename=rekap-absensi.csv');
    res.send('\uFEFF' + csvHeader + csvRows);
  });

  app.get("/api/admin/qrcode/:userId", requireRole("admin"), async (req: Request, res: Response) => {
    const user = await storage.getUser(parseInt(req.params.userId));
    if (!user) return res.status(404).json({ message: "User not found" });
    const { password: _, ...safeUser } = user;
    res.json(safeUser);
  });

  app.get("/api/admin/qrcodes", requireRole("admin"), async (req: Request, res: Response) => {
    const { role, className } = req.query;
    const list = await storage.getUsers(role as string | undefined, className as string | undefined);
    const safeList = list
      .filter(u => u.role !== "admin")
      .map(({ password, ...u }) => u);
    res.json(safeList);
  });

  // EXCUSE ROUTES
  app.post("/api/excuses", requireAuth, upload.single("photo"), async (req: Request, res: Response) => {
    try {
      const { date, type, description } = req.body;
      if (!date || !type || !description) {
        return res.status(400).json({ message: "Data tidak lengkap" });
      }

      let photoUrl: string | null = null;
      let driveFileId: string | null = null;

      if (req.file) {
        const user = await storage.getUser(req.session.userId!);
        const fileName = `izin_${user?.name}_${date}_${Date.now()}.${req.file.originalname.split('.').pop()}`;
        const result = await uploadExcusePhoto(req.file.buffer, fileName, req.file.mimetype);
        if (result) {
          driveFileId = result.fileId;
          photoUrl = result.webViewLink;
        }
      }

      const excuse = await storage.createExcuse({
        userId: req.session.userId!,
        date,
        type: type as "sakit" | "izin",
        description,
        photoUrl,
        driveFileId,
        status: "pending",
      });

      const existing = await storage.getAttendance(req.session.userId!, date);
      if (!existing) {
        await storage.createAttendance({
          userId: req.session.userId!,
          date,
          checkInTime: null,
          checkOutTime: null,
          status: type as "sakit" | "izin",
        });
      } else {
        await storage.updateAttendance(existing.id, { status: type as "sakit" | "izin" });
      }

      const student = await storage.getUser(req.session.userId!);
      if (student) {
        appendAttendanceRow({ date, name: student.name, identifier: student.identifier, className: student.className || "-", checkInTime: "-", checkOutTime: "-", status: type, role: student.role }).catch(console.error);
      }
      if (student?.className) {
        const homeroomTeachers = await storage.getUsers("wali_kelas", student.className);
        for (const wali of homeroomTeachers) {
          if (wali.parentPhone) {
            const driveLink = driveFileId ? `https://drive.google.com/file/d/${driveFileId}/view` : undefined;
            sendExcuseNotificationToHomeroom(
              wali.parentPhone, wali.name, student.name, student.className,
              type, date, description, driveLink
            ).catch(err => console.error("Failed to send WA to homeroom:", err));
          }
        }
      }

      res.json(excuse);
    } catch (error) {
      console.error("Create excuse error:", error);
      res.status(500).json({ message: "Server error" });
    }
  });

  app.get("/api/excuses", requireAuth, async (req: Request, res: Response) => {
    const role = req.session.role!;
    if (role === "admin") {
      const list = await storage.getExcuses();
      return res.json(list);
    }
    if (role === "wali_kelas") {
      const user = await storage.getUser(req.session.userId!);
      if (user?.className) {
        const list = await storage.getExcusesByClass(user.className);
        return res.json(list);
      }
    }
    const list = await storage.getExcuses(req.session.userId!);
    res.json(list);
  });

  app.put("/api/excuses/:id/status", requireRole("admin", "wali_kelas"), async (req: Request, res: Response) => {
    try {
      const { status } = req.body;
      if (!["approved", "rejected"].includes(status)) {
        return res.status(400).json({ message: "Status tidak valid" });
      }
      const updated = await storage.updateExcuseStatus(parseInt(req.params.id), status);
      if (!updated) return res.status(404).json({ message: "Not found" });
      res.json(updated);
    } catch (error) {
      console.error("Update excuse error:", error);
      res.status(500).json({ message: "Server error" });
    }
  });

  // ATTENDANCE HISTORY (for logged-in users)
  app.get("/api/attendance/history", requireAuth, async (req: Request, res: Response) => {
    const records = await storage.getUserAttendanceHistory(req.session.userId!);
    res.json(records);
  });

  // CLASS ATTENDANCE (for wali_kelas and guru)
  app.get("/api/class/attendance", requireRole("wali_kelas", "guru"), async (req: Request, res: Response) => {
    const user = await storage.getUser(req.session.userId!);
    const { date, className: qClassName } = req.query;
    const targetClass = user?.role === "guru" ? (qClassName as string) : user?.className;
    if (!targetClass) return res.json([]);
    const targetDate = (date as string) || getCurrentDate();
    const students = await storage.getUsers("siswa", targetClass);
    const result = [];
    for (const student of students) {
      const att = await storage.getAttendance(student.id, targetDate);
      const { password: _, ...safeStudent } = student;
      result.push({
        student: safeStudent,
        attendance: att || null,
      });
    }
    res.json(result);
  });

  app.get("/api/class/students", requireRole("wali_kelas", "guru"), async (req: Request, res: Response) => {
    const user = await storage.getUser(req.session.userId!);
    const { className: qClassName } = req.query;
    const targetClass = user?.role === "guru" ? (qClassName as string) : user?.className;
    if (!targetClass) return res.json([]);
    const students = await storage.getUsers("siswa", targetClass);
    const safeList = students.map(({ password, ...u }) => u);
    res.json(safeList);
  });

  app.get("/api/classes", requireRole("guru", "wali_kelas", "admin"), async (_req: Request, res: Response) => {
    const allStudents = await storage.getUsers("siswa");
    const classes = [...new Set(allStudents.map(s => s.className).filter(Boolean))].sort();
    res.json(classes);
  });

  return httpServer;
}
